Para cualquier duda sobre los sdk porfavor consultar el siguiente video: 
https://www.youtube.com/watch?v=_2eXg4FZ6Ic&feature=youtu.be