﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;//Librería de kinect
using Microsoft.Kinect.Toolkit;//Librería con fucniones para el funcionamiento de las demás librerías
using Microsoft.Kinect.Toolkit.Controls;//Librería con controles de de Kinect
using System.IO.Ports;//Librería para manejar conexión con arduino

namespace WpfApp
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        KinectSensorChooser mikinect; //Objeto que manejará al kinect
        SerialPort serial = new SerialPort();//Objeto que manejará la conexión con arduino
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            mikinect = new KinectSensorChooser(); //La instanciación de este objeto sirve 
            //para configurar el objeto de kinect
           
            mikinect.KinectChanged += mikinect_KinectChanged; //El método Kinect changed detecta si el kinect está
            //conectado o desconectado
            //La llamada al evento de mikinect_KinectChanged captura el evento en caso de que el kinect haya sido desconectado o reconcetado
            //para que posteriormente se manejado
            KinectSensorChooserUI.KinectSensorChooser = mikinect;
            //La propiedad del KinectSensorChooser permite establecer al elemento de mi kinect como el sensor a usar y 
            //permite visualizarlo en pantalla
            mikinect.Start();
            //El kinect se inicializa para usar

            serial.PortName = "COM8"; //Se establece el puerto por el cual se enviará la señal a arduino
            serial.BaudRate = 9600; //La velocidad de la comunicación serial que se transmitirá al arduino
            serial.Open(); //Abre la conexión con el arduino
        }

        void mikinect_KinectChanged(object sender, KinectChangedEventArgs e)
        {
            //Los eventos KinectChangedEventArgs permiten captar conexión o desconexión
            //de kinect usando las dos propiedades de OldSensor y NewSensor
            bool error = true;//Esta variable identificará si existe o no un error en el evento
            //Si el kinect está desconectado la propiedad oldsensor será null
            if (e.OldSensor == null)
            {
                //COn el try y catch se verificárá si se puede deshabilitar la spropiedades del evento
                try
                {
                    e.OldSensor.DepthStream.Disable();
                    e.OldSensor.SkeletonStream.Disable();
                }
                catch (Exception)
                {
                    error = true;
                }
            }

            if (e.NewSensor == null)//Si el new sensor el null significa que el Kinect está conectado
                return;
            //Se procede a realizar las habilitaciones de las propiedades de profundidad y de esqueleto
            try
            {
                e.NewSensor.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30);
                e.NewSensor.SkeletonStream.Enable();

                try
                {
                    e.NewSensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;//Sirve en caso de que el usuario esté sentado
                    e.NewSensor.DepthStream.Range = DepthRange.Near;//Rango de profundidad tiene que ser cercano
                    e.NewSensor.SkeletonStream.EnableTrackingInNearRange = true;// Rango de esqueleto a captar tambien debe ser cercano
                }
                catch (InvalidOperationException)
                {
                    //Aqui se desactivan las propiedades previamente habilitadas en caso de error
                    e.NewSensor.DepthStream.Range = DepthRange.Default;
                    e.NewSensor.SkeletonStream.EnableTrackingInNearRange = false;
                }
            }
            catch (InvalidOperationException)
            {
                error = true;
            }

            ZonaCursor.KinectSensor = e.NewSensor;//La region del kinect está habilitada y lista para usarse con el sensor configurado previamente
        }

        private void KinectTileButton_Click_1(object sender, RoutedEventArgs e)
        {
            
            serial.WriteLine("A");//Envia señal digital de 1 al arduino 
            
        }



        private void KinectTileButton_Click(object sender, RoutedEventArgs e)
        {
            
            serial.WriteLine("B");//Envia señal digital de 0 al arduino
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            //Cuando se está cerrando la venta se envia señal digital de 0 al arduino y se cierra la conexión serial
            if (serial.IsOpen)
            {
                serial.WriteLine("B");
                serial.Close();
            }
        }
    }
    
}
